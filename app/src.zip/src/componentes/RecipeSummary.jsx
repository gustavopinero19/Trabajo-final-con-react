import React from 'react';

const RecipeSummary = ({ score }) => {
  return (
    <div>
      <h3>Puntaje nutricional: {score}</h3>
    </div>
  );
};

export default RecipeSummary;
